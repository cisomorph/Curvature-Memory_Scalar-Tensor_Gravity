import numpy as np
import sys
sys.path.insert(0, '/home/aion/Desktop/planck_packages/code/planck/clipy')
import clipy

clik = clipy.clik('/home/aion/Desktop/planck_packages/data/planck_2018/baseline/plc_3.0/hi_l/plik/plik_rd12_HM_v22b_TTTEEE.clik')
par = np.array(clik._default_par)
print(f"Default par length: {len(par)}")
print(f"lmax: {clik.get_lmax()}")
print(f"Nuisance names: {clik.get_extra_parameter_names()}")
# TT runs from ell=0..2508 → first 2509 elements
TT = par[:2509]
print()
print("TT default_par values at selected ells:")
for l in [2, 10, 50, 100, 200, 500, 1000, 2000]:
    Dl_if_raw = TT[l] * l*(l+1)/(2*np.pi)
    print(f"  l={l:4d}: value={TT[l]:.6e}  Dl_if_raw={Dl_if_raw:.4f} muK^2  (if this IS Dl: {TT[l]:.4f})")
print()
print("Interpretation:")
print(f"  TT[200] = {TT[200]:.4f}")
print(f"  If Cl (muK^2): Dl = {TT[200]*200*201/(2*np.pi):.2f} muK^2 (expect ~5787)")
print(f"  If Dl (muK^2): already Dl = {TT[200]:.2f} muK^2 (expect ~5787)")
